<?php Global $T;$T = array (
);